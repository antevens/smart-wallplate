G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,9.0.9-9.0.9~ubuntu24.04.1*
G04 #@! TF.CreationDate,2026-10-09T06:39:34+00:00*
G04 #@! TF.ProjectId,eu_5v_board,65755f35-765f-4626-9f61-72642e6b6963,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.9-9.0.9~ubuntu24.04.1) date 2026-10-09 06:39:34*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10C,2.200000*%
%ADD11RoundRect,0.250000X0.650000X-0.325000X0.650000X0.325000X-0.650000X0.325000X-0.650000X-0.325000X0*%
%ADD12R,1.700000X1.700000*%
%ADD13C,1.700000*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,P2*
X25900000Y-9000000D03*
G04 #@! TD*
G04 #@! TO.C,P1*
X25900000Y-4600000D03*
G04 #@! TD*
G04 #@! TO.C,MH1*
X-12000000Y-22000000D03*
G04 #@! TD*
G04 #@! TO.C,MH2*
X16000000Y-21000000D03*
G04 #@! TD*
D11*
G04 #@! TO.C,C1*
X16000000Y-8275000D03*
X16000000Y-5325000D03*
G04 #@! TD*
D12*
G04 #@! TO.C,J1*
X-5000000Y-20500000D03*
D13*
X-5000000Y-23040000D03*
G04 #@! TD*
M02*
